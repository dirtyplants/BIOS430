utils::globalVariables(c("URLencode", "browseURL", "capture.output",
                         "file.edit", "getS3method", "head", "install.packages",
                         "packageVersion", "read.csv", "select.list", "sessionInfo",
                         "setTxtProgressBar", "tail", "txtProgressBar", "unzip",
                         "zip"))
